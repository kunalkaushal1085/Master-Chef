raw = 5
for i in range(raw):
    print("*" * i)


r = 5
for i in range(1,r +1):
    print(" " * (r - i) + "*" * (2*i-1))


glist = [1,5,8,8,3,5,2,2,3,4,5,6]
ulist = list(set(glist))
print(ulist)

g = [1,5,8,8,3,5,2,2,3,4,5,6]
ulist = []
seen =set()
for i in g:
    if i not in ulist:
        ulist.append(i)
        seen.add(i)
print(ulist)
